package org.atricore.samples.springsecurity.idau;

public class OpenIDUIApplication extends org.atricore.idbus.capabilities.openid.ui.internal.OpenIDUIApplication {

    //  Simple java class that extends a parent
}
