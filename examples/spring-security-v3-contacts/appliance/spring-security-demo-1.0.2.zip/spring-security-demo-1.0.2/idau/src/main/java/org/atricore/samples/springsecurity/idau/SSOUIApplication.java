package org.atricore.samples.springsecurity.idau;

public class SSOUIApplication extends org.atricore.idbus.capabilities.sso.ui.internal.SSOUIApplication {

    //  Simple java class that extends a parent
}
